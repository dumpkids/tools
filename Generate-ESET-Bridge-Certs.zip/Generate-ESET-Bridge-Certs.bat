@echo off
setlocal
set "ESET_GEN_FILE=%~f0"
set "ESET_GEN_DIR=%~dp0"
title ESET Bridge Certificate Generator - 10 Years
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { $source=[System.IO.File]::ReadAllText($env:ESET_GEN_FILE); $parts=$source -split '(?m)^::PS_PAYLOAD_START\r?$',2; if($parts.Count -ne 2){throw 'PowerShell payload not found in BAT file.'}; & ([ScriptBlock]::Create($parts[1])); exit 0 } catch { Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Pembuatan sertifikat GAGAL. Baca pesan error di atas.
if "%RESULT%"=="0" echo Selesai. Tekan tombol untuk menutup.
pause
exit /b %RESULT%
::PS_PAYLOAD_START
$ErrorActionPreference = 'Stop'

Write-Host ''
Write-Host '===============================================' -ForegroundColor Cyan
Write-Host ' ESET Bridge HTTPS Certificate Generator' -ForegroundColor Cyan
Write-Host ' Windows 11 - masa berlaku 10 tahun' -ForegroundColor Cyan
Write-Host '===============================================' -ForegroundColor Cyan
Write-Host ''
Write-Host 'Buat 3 file: eset-bridge.pfx, eset-bridge-ca.der, backup-eset-bridge-ca.pfx'
Write-Host 'Satu password dipakai pada kedua file PFX. Password tidak disimpan di script.'
Write-Host ''

# Hanya satu input: password PFX, tersembunyi saat diketik.
$password = Read-Host 'Masukkan password untuk kedua file PFX' -AsSecureString
if ($null -eq $password -or $password.Length -lt 8) {
    throw 'Password minimum 8 karakter.'
}

# Tanggal yang sama untuk CA dan sertifikat server: 10 tahun dari sekarang.
$issuedAt = Get-Date
$expiresAt = $issuedAt.AddYears(10)

# Folder hasil baru setiap kali dijalankan; tidak menimpa file sebelumnya.
$baseFolder = Join-Path $env:ESET_GEN_DIR 'ESET-Bridge-Certs'
$stamp = $issuedAt.ToString('yyyyMMdd-HHmmss')
$outputFolder = Join-Path $baseFolder $stamp
$counter = 2
while (Test-Path -LiteralPath $outputFolder) {
    $outputFolder = Join-Path $baseFolder ($stamp + '-' + $counter)
    $counter++
}
New-Item -ItemType Directory -Path $outputFolder -Force | Out-Null

$caDer = Join-Path $outputFolder 'eset-bridge-ca.der'
$bridgePfx = Join-Path $outputFolder 'eset-bridge.pfx'
$caBackupPfx = Join-Path $outputFolder 'backup-eset-bridge-ca.pfx'

$domains = @(
    '*.eset.com',
    '*.eset.net',
    '*.eset.systems',
    '*.eset.eu',
    '*.update.eset.com',
    '*.cn.eset.com',
    '*.edtd.eset.com',
    '*.edtd.eset.systems'
)

Write-Host '[1/4] Membuat Private CA...' -ForegroundColor Yellow
$ca = New-SelfSignedCertificate `
    -Type Custom `
    -Subject 'CN=ESET Bridge Private Root CA' `
    -KeyAlgorithm RSA `
    -KeyLength 3072 `
    -HashAlgorithm SHA256 `
    -KeyUsage CertSign,CRLSign `
    -KeyUsageProperty Sign `
    -KeyExportPolicy Exportable `
    -CertStoreLocation 'Cert:\CurrentUser\My' `
    -NotBefore $issuedAt.AddMinutes(-10) `
    -NotAfter $expiresAt `
    -TextExtension @('2.5.29.19={critical}{text}ca=true&pathlength=0')

Write-Host '[2/4] Membuat sertifikat HTTPS Bridge...' -ForegroundColor Yellow
$bridge = New-SelfSignedCertificate `
    -Type Custom `
    -Subject 'CN=ESET Bridge at *.eset.com' `
    -DnsName $domains `
    -Signer $ca `
    -KeyAlgorithm RSA `
    -KeyLength 3072 `
    -HashAlgorithm SHA256 `
    -KeyUsage DigitalSignature,KeyEncipherment,KeyAgreement `
    -KeyExportPolicy Exportable `
    -CertStoreLocation 'Cert:\CurrentUser\My' `
    -NotBefore $issuedAt.AddMinutes(-5) `
    -NotAfter $expiresAt `
    -TextExtension @(
        '2.5.29.19={critical}{text}ca=false',
        '2.5.29.37={text}1.3.6.1.5.5.7.3.1'
    )

Write-Host '[3/4] Mengekspor 3 file...' -ForegroundColor Yellow
Export-Certificate -Cert $ca -FilePath $caDer -Type CERT | Out-Null
Export-PfxCertificate -Cert $bridge -FilePath $bridgePfx -Password $password `
    -ChainOption EndEntityCertOnly -CryptoAlgorithmOption AES256_SHA256 | Out-Null
Export-PfxCertificate -Cert $ca -FilePath $caBackupPfx -Password $password `
    -ChainOption EndEntityCertOnly -CryptoAlgorithmOption AES256_SHA256 | Out-Null

Write-Host '[4/4] Memeriksa isi sertifikat...' -ForegroundColor Yellow
foreach ($f in @($caDer, $bridgePfx, $caBackupPfx)) {
    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { throw ('File tidak ada: ' + $f) }
    if ((Get-Item -LiteralPath $f).Length -le 0) { throw ('File kosong: ' + $f) }
}

# Validasi CA, issuer Bridge, delapan domain SAN, masa berlaku, dan backup PFX.
if ($bridge.Issuer -ne $ca.Subject) { throw 'Issuer sertifikat Bridge tidak sesuai dengan Root CA.' }
if ($bridge.NotAfter -ne $ca.NotAfter) { throw 'Tanggal expired CA dan Bridge tidak sama.' }
$caBasicConstraints = $ca.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.19' } | Select-Object -First 1
if ($null -eq $caBasicConstraints) { throw 'Basic Constraints CA tidak ditemukan.' }
$sanExt = $bridge.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' } | Select-Object -First 1
if ($null -eq $sanExt) { throw 'Ekstensi SAN tidak ditemukan.' }
$sanText = $sanExt.Format($false)
foreach ($domain in $domains) {
    if (-not $sanText.Contains($domain)) { throw ('Domain SAN tidak ada: ' + $domain) }
}
$ekuExt = $bridge.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.37' } | Select-Object -First 1
if ($null -eq $ekuExt) { throw 'Server Authentication EKU tidak ditemukan.' }

$null = Get-PfxData -FilePath $bridgePfx -Password $password
$null = Get-PfxData -FilePath $caBackupPfx -Password $password

Write-Host ''
Write-Host 'BERHASIL - 3 sertifikat selesai dibuat.' -ForegroundColor Green
Write-Host ('Dibuat : ' + $issuedAt.ToString('yyyy-MM-dd HH:mm:ss'))
Write-Host ('Expired: ' + $expiresAt.ToString('yyyy-MM-dd HH:mm:ss'))
Write-Host ('Folder : ' + $outputFolder)
Write-Host ''
Get-ChildItem -LiteralPath $outputFolder | Select-Object Name, Length | Format-Table -AutoSize
Write-Host 'Import eset-bridge.pfx ke policy ESET Bridge (HTTPS Certificate).' -ForegroundColor Cyan
Write-Host 'Import eset-bridge-ca.der ke policy ESET Endpoint (Certificate Authorities).' -ForegroundColor Cyan
Write-Host 'SIMPAN backup-eset-bridge-ca.pfx secara offline. Jangan upload backup CA ke ESET.' -ForegroundColor Yellow
Write-Host 'Jangan pasang CA sebagai Trusted Root Windows secara global.' -ForegroundColor Yellow
Write-Host ''
