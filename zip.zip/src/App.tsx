/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './components/layout/MainLayout';
import Dashboard from './pages/Dashboard';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          {/* Temporary placeholder routes to prevent 404s when clicking sidebar */}
          <Route path="*" element={
            <div className="flex h-64 items-center justify-center">
              <p className="text-xl text-slate-500">Membangun Modul...</p>
            </div>
          } />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
