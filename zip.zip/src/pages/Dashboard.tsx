import React from "react";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: "Total Invoice (Bulan Ini)", value: "Rp 125.000.000", subtitle: "12 Dokumen" },
          { title: "Total Penawaran (Bulan Ini)", value: "Rp 340.000.000", subtitle: "24 Dokumen" },
          { title: "Menunggu Approval", value: "5", subtitle: "Dokumen perlu ditindaklanjuti" },
          { title: "Penawaran Dikonversi", value: "8", subtitle: "Success rate 33%" },
        ].map((stat, i) => (
          <div key={i} className="p-4 rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950 shadow-sm">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">{stat.title}</h3>
            <p className="mt-2 text-2xl font-bold">{stat.value}</p>
            <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">{stat.subtitle}</p>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-950 shadow-sm min-h-[300px]">
        <h2 className="text-lg font-semibold mb-4">Aktivitas Terbaru</h2>
        <div className="flex h-full items-center justify-center text-slate-500">
          <p>Fitur ringkasan belum dimuat karena tidak ada data.</p>
        </div>
      </div>
    </div>
  );
}
