import QRCode from 'qrcode';

/**
 * Men-generate QR Code dalam format Base64
 * @param domain - Domain aplikasi (contoh: https://app.imamultitek.com)
 * @param documentType - 'invoice' atau 'quotation'
 * @param documentId - UUID dokumen
 * @param token - Secure token (UUID)
 * @returns Base64 image string
 */
export const generateQRBase64 = async (
    domain: string,
    documentType: string,
    documentId: string,
    token: string
): Promise<string> => {
    const url = `${domain}/verify/${documentType.toLowerCase()}/${documentId}?token=${token}`;
    
    try {
        const qrBase64 = await QRCode.toDataURL(url, {
            errorCorrectionLevel: 'H',
            margin: 1,
            width: 150,
            color: {
                dark: '#000000',
                light: '#ffffff'
            }
        });
        return qrBase64;
    } catch (error) {
        console.error('Error generating QR Code:', error);
        throw new Error('Gagal men-generate QR Code');
    }
};
