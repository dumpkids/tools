import crypto from 'crypto';

/**
 * Men-generate secure random token.
 * Karena skema database menggunakan tipe UUID untuk verification_token,
 * kita menggunakan crypto.randomUUID() bawaan Node.js yang menghasilkan UUID v4 kriptografis.
 */
export const generateSecureToken = () => {
    return crypto.randomUUID();
};
