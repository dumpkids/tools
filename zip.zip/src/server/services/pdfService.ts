import puppeteer from 'puppeteer';
import * as fs from 'fs/promises';
import * as path from 'path';

const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', { 
        style: 'currency', 
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
};

const formatDate = (dateString: string | Date | null) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
};

export const generateDocumentPDF = async (documentData: any, type: string, qrCodeBase64: string) => {
    const isInvoice = type.toUpperCase() === 'INVOICE';
    const docTitle = isInvoice ? 'INVOICE' : 'PENAWARAN SERVICE';
    const docNumber = isInvoice ? documentData.invoice_number : documentData.quotation_number;
    
    // Render baris tabel item
    const itemsHtml = documentData.items.map((item: any, index: number) => `
        <tr>
            <td style="text-align: center; border: 1px solid #000; padding: 8px;">${index + 1}</td>
            <td style="border: 1px solid #000; padding: 8px;">${item.product_name}</td>
            <td style="text-align: center; border: 1px solid #000; padding: 8px;">${item.qty}</td>
            <td style="text-align: center; border: 1px solid #000; padding: 8px;">${item.unit}</td>
            <td style="text-align: right; border: 1px solid #000; padding: 8px;">${formatCurrency(item.unit_price)}</td>
            <td style="text-align: right; border: 1px solid #000; padding: 8px;">${formatCurrency(item.total_price)}</td>
            <td style="border: 1px solid #000; padding: 8px;">${item.description || '-'}</td>
        </tr>
    `).join('');

    const htmlContent = `
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: 'Helvetica', 'Arial', sans-serif; font-size: 12px; color: #000; margin: 0; padding: 20px 40px; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #000; padding-bottom: 10px; }
            .company-name { font-size: 24px; font-weight: bold; margin: 0 0 5px 0; }
            .company-info { font-size: 11px; margin: 2px 0; }
            .doc-title { text-align: center; font-size: 20px; font-weight: bold; margin: 20px 0; letter-spacing: 2px; }
            .info-table { width: 100%; margin-bottom: 20px; }
            .info-table td { vertical-align: top; padding: 3px; }
            .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .items-table th { border: 1px solid #000; padding: 8px; background-color: #f0f0f0; text-align: center; font-weight: bold; }
            .total-row td { font-weight: bold; border: 1px solid #000; padding: 8px; }
            .footer-section { margin-top: 30px; width: 100%; display: table; }
            .notes { display: table-cell; width: 60%; vertical-align: top; font-size: 11px; }
            .signature-area { display: table-cell; width: 40%; text-align: center; vertical-align: top; }
            .qr-code { width: 100px; height: 100px; margin: 10px auto; }
            .signer-name { font-weight: bold; text-decoration: underline; margin-bottom: 2px; }
            .verify-text { font-size: 9px; color: #555; margin-top: 5px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1 class="company-name">PT. IMA MULTITEK INDONESIA</h1>
            <p class="company-info">Dusun Ploso RT 04 RW 06, Randuacir, Argomulyo, Kota Salatiga, Jawa Tengah 50735</p>
            <p class="company-info">Telp/WA : 0818292047 | Email : imam@multitekindo.com</p>
        </div>

        <div class="doc-title">${docTitle}</div>

        <table class="info-table">
            <tr>
                <td style="width: 15%;"><strong>Kepada Yth.</strong></td>
                <td style="width: 45%;">: ${documentData.company_name}</td>
                <td style="width: 15%;"><strong>No. ${isInvoice ? 'Invoice' : 'Penawaran'}</strong></td>
                <td style="width: 25%;">: ${docNumber}</td>
            </tr>
            <tr>
                <td><strong>Alamat</strong></td>
                <td>: ${documentData.address}</td>
                <td><strong>Tanggal</strong></td>
                <td>: ${formatDate(documentData.date)}</td>
            </tr>
            <tr>
                <td><strong>PIC</strong></td>
                <td>: ${documentData.pic_name} (${documentData.contact_number})</td>
                ${isInvoice ? `
                <td><strong>PO Customer</strong></td>
                <td>: ${documentData.po_customer || '-'}</td>
                ` : `
                <td><strong>Perihal</strong></td>
                <td>: ${documentData.subject || '-'}</td>
                `}
            </tr>
            ${isInvoice ? `
            <tr>
                <td></td>
                <td></td>
                <td><strong>Tgl Jatuh Tempo</strong></td>
                <td>: ${formatDate(documentData.due_date)}</td>
            </tr>
            ` : ''}
        </table>

        <table class="items-table">
            <thead>
                <tr>
                    <th style="width: 5%;">NO</th>
                    <th style="width: 30%;">NAMA BARANG</th>
                    <th style="width: 5%;">QTY</th>
                    <th style="width: 10%;">SATUAN</th>
                    <th style="width: 15%;">HARGA/UNIT</th>
                    <th style="width: 15%;">TOTAL</th>
                    <th style="width: 20%;">KETERANGAN</th>
                </tr>
            </thead>
            <tbody>
                ${itemsHtml}
                <tr class="total-row">
                    <td colspan="5" style="text-align: right;">TOTAL ${isInvoice ? 'TAGIHAN' : 'HARGA'}</td>
                    <td style="text-align: right;">${formatCurrency(documentData.total_amount)}</td>
                    <td></td>
                </tr>
            </tbody>
        </table>

        <div class="footer-section">
            <div class="notes">
                ${isInvoice ? `
                <strong>Informasi Pembayaran:</strong><br>
                Pembayaran via transfer BNI 4158885552 An. PT IMA MULTITEK INDONESIA
                ` : `
                <strong>Keterangan dan Ketentuan:</strong><br>
                ${documentData.terms_conditions}
                `}
            </div>
            <div class="signature-area">
                <div>Hormat Kami,</div>
                <img src="${qrCodeBase64}" class="qr-code" alt="QR Verification" />
                <div class="signer-name">Imam Solichi</div>
                <div class="verify-text">Scan QR code untuk memverifikasi keaslian dokumen ini.</div>
            </div>
        </div>
    </body>
    </html>
    `;

    const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(htmlContent, { waitUntil: 'load' });
    
    const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: { top: '20px', right: '20px', bottom: '20px', left: '20px' }
    });

    await browser.close();

    const fileName = `${docTitle.replace(/ /g, '_')}_${docNumber.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.pdf`;
    const dirPath = path.join(process.cwd(), 'public/documents');
    
    await fs.mkdir(dirPath, { recursive: true });
    
    const filePath = path.join(dirPath, fileName);
    await fs.writeFile(filePath, pdfBuffer);

    return {
        buffer: pdfBuffer,
        fileName: fileName,
        filePath: `/documents/${fileName}`
    };
};
