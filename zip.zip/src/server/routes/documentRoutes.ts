import express from 'express';
import { approveDocument, verifyDocument } from '../controllers/documentController';

const router = express.Router();

// Internal endpoint for approval
router.post('/approve', approveDocument);

// Public verification endpoint
router.get('/verify', verifyDocument);

export default router;
