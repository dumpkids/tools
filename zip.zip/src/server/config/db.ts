import { Pool } from 'pg';

let pool: Pool;

// Using a fallback for testing without a real database setup
const DATABASE_URL = process.env.DATABASE_URL;

if (DATABASE_URL) {
    pool = new Pool({
        connectionString: DATABASE_URL,
    });
} else {
    console.warn("WARNING: process.env.DATABASE_URL is not set.");
    console.warn("Using mock database pool. Operations will fail unless mocked.");
    
    // Create a mock pool that won't crash on load but will error gracefully on use
    pool = {
        query: async (...args: any[]) => {
            throw new Error(`Database connection not configured (DATABASE_URL missing). Query attempted: ${args[0]}`);
        },
        connect: async () => {
            return {
                query: async (...args: any[]) => {
                    throw new Error(`Database connection not configured (DATABASE_URL missing). Query attempted: ${args[0]}`);
                },
                release: () => {},
            };
        }
    } as any;
}

export default pool;
