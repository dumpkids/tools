import { Request, Response } from 'express';
import pool from '../config/db';
import { generateSecureToken } from '../utils/cryptoUtils';
import { generateQRBase64 } from '../utils/qrGenerator';
import { generateDocumentPDF } from '../services/pdfService';

const DOMAIN_URL = process.env.APP_URL || 'http://localhost:3000';

export const approveDocument = async (req: Request, res: Response): Promise<any> => {
    const { documentId, type } = req.body;
    // Mock user for now since auth middleware isn't set up
    const userId = '00000000-0000-0000-0000-000000000000'; 

    if (!documentId || !type) {
        return res.status(400).json({ error: 'documentId dan type wajib diisi' });
    }

    const isInvoice = type.toUpperCase() === 'INVOICE';
    const tableName = isInvoice ? 'invoices' : 'quotations';
    const itemsTableName = isInvoice ? 'invoice_items' : 'quotation_items';
    const foreignKey = isInvoice ? 'invoice_id' : 'quotation_id';

    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        const docCheck = await client.query(`SELECT status FROM ${tableName} WHERE id = $1`, [documentId]);
        if (docCheck.rows.length === 0) {
            throw new Error('Dokumen tidak ditemukan');
        }
        if (docCheck.rows[0].status === 'APPROVED' || docCheck.rows[0].status === 'PAID') {
            throw new Error('Dokumen sudah di-approve sebelumnya');
        }

        const secureToken = generateSecureToken();

        await client.query(`
            UPDATE ${tableName} 
            SET status = 'APPROVED', verification_token = $1, approved_by = $2, updated_at = NOW()
            WHERE id = $3
        `, [secureToken, userId, documentId]);

        const docQuery = await client.query(`
            SELECT d.*, c.company_name, c.address, c.pic_name, c.contact_number 
            FROM ${tableName} d
            JOIN customers c ON d.customer_id = c.id
            WHERE d.id = $1
        `, [documentId]);
        const documentData = docQuery.rows[0];

        const itemsQuery = await client.query(`
            SELECT * FROM ${itemsTableName} WHERE ${foreignKey} = $1 ORDER BY sort_order ASC
        `, [documentId]);
        documentData.items = itemsQuery.rows;

        const qrBase64 = await generateQRBase64(DOMAIN_URL, type, documentId, secureToken);

        const pdfResult = await generateDocumentPDF(documentData, type, qrBase64);

        await client.query(`
            INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details)
            VALUES ($1, 'APPROVE_DOCUMENT', $2, $3, $4)
        `, [userId, type.toUpperCase(), documentId, JSON.stringify({ pdf_path: pdfResult.filePath })]);

        await client.query('COMMIT');

        return res.status(200).json({
            message: 'Dokumen berhasil di-approve dan PDF di-generate',
            data: {
                documentId,
                status: 'APPROVED',
                pdfUrl: pdfResult.filePath
            }
        });

    } catch (error: any) {
        await client.query('ROLLBACK');
        console.error('Approval Error:', error);
        return res.status(500).json({ error: error.message || 'Terjadi kesalahan pada server' });
    } finally {
        client.release();
    }
};

export const verifyDocument = async (req: Request, res: Response): Promise<any> => {
    const { type, documentId, token } = req.query;

    if (!type || !documentId || !token) {
        return res.status(400).json({ error: 'Parameter type, documentId, dan token wajib diisi' });
    }

    const isInvoice = (type as string).toUpperCase() === 'INVOICE';
    const tableName = isInvoice ? 'invoices' : 'quotations';
    const docNumberField = isInvoice ? 'invoice_number' : 'quotation_number';

    try {
        const query = `
            SELECT d.${docNumberField} AS document_number, d.date, d.total_amount, d.status, 
                   c.company_name AS customer_name
            FROM ${tableName} d
            JOIN customers c ON d.customer_id = c.id
            WHERE d.id = $1 AND d.verification_token = $2
        `;
        
        const result = await pool.query(query, [documentId, token]);

        if (result.rows.length === 0) {
            return res.status(404).json({ 
                isValid: false, 
                message: 'Dokumen tidak ditemukan atau token tidak valid' 
            });
        }

        const doc = result.rows[0];
        const validStatuses = ['APPROVED', 'PAID', 'CONVERTED'];
        const isValid = validStatuses.includes(doc.status);

        return res.status(200).json({
            isValid: isValid,
            data: {
                documentType: (type as string).toUpperCase(),
                documentNumber: doc.document_number,
                date: doc.date,
                customer: doc.customer_name,
                totalAmount: doc.total_amount,
                signer: 'Imam Solichi',
                status: doc.status,
                verificationMessage: isValid ? 'Dokumen Resmi dan Valid' : 'Dokumen telah dibatalkan atau tidak valid'
            }
        });

    } catch (error: any) {
        console.error('Verification Error:', error);
        return res.status(500).json({ error: 'Terjadi kesalahan saat memverifikasi dokumen' });
    }
};
