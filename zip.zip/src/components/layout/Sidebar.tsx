import React from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  FileText, 
  FileSignature, 
  Users, 
  Building2, 
  Package, 
  ShieldCheck,
  Database
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const location = useLocation();
  const pathname = location.pathname;

  const menuGroups = [
    {
      title: "Main Menu",
      items: [
        { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
        { name: "Invoices", href: "/invoices", icon: FileText },
        { name: "Quotations", href: "/quotations", icon: FileSignature },
      ],
    },
    {
      title: "Master Data",
      items: [
        { name: "Company Profile", href: "/master/company", icon: Building2 },
        { name: "Customers", href: "/master/customers", icon: Users },
        { name: "Products & Services", href: "/master/products", icon: Package },
        { name: "User Management", href: "/master/users", icon: ShieldCheck },
      ],
    },
    {
      title: "System",
      items: [
        { name: "Audit Logs", href: "/system/audit-logs", icon: Database },
      ],
    }
  ];

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-30 mt-16 w-64 transform overflow-y-auto border-r border-slate-200 bg-white transition-transform duration-300 ease-in-out dark:border-slate-800 dark:bg-slate-950 lg:static lg:mt-0 lg:translate-x-0 ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      <div className="flex flex-col gap-6 p-4">
        {menuGroups.map((group, index) => (
          <div key={index}>
            <h3 className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              {group.title}
            </h3>
            <div className="flex flex-col gap-1">
              {group.items.map((item) => {
                const isActive = pathname.startsWith(item.href);
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-blue-600 text-white shadow-sm dark:bg-blue-600"
                        : "text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/50"
                    }`}
                  >
                    <Icon className={`h-5 w-5 ${isActive ? "text-white" : "text-slate-400 dark:text-slate-500"}`} />
                    {item.name}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </aside>
  );
}
